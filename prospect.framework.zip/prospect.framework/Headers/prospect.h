//
//  prospect.h
//  prospect
//
//  Created by Juan Reynaldo Escobar Miron on 16/03/18.
//  Copyright © 2018 reyhac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaseClases/BaseClases.h>

@import AudioToolbox;
@import AVFoundation;
@import CoreMedia;
@import CoreVideo;
@import MobileCoreServices;


//! Project version number for prospect.
FOUNDATION_EXPORT double prospectVersionNumber;

//! Project version string for prospect.
FOUNDATION_EXPORT const unsigned char prospectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <prospect/PublicHeader.h>


