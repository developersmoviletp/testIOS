//
//  account.h
//  account
//
//  Created by Juan Reynaldo Escobar Miron on 13/03/18.
//  Copyright © 2018 Juan Reynaldo Escobar Miron. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for account.
FOUNDATION_EXPORT double accountVersionNumber;

//! Project version string for account.
FOUNDATION_EXPORT const unsigned char accountVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <account/PublicHeader.h>


