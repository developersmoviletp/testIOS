//
//  trace.h
//  trace
//
//  Created by Juan Reynaldo Escobar Miron on 13/03/18.
//  Copyright © 2018 reyhac. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for trace.
FOUNDATION_EXPORT double traceVersionNumber;

//! Project version string for trace.
FOUNDATION_EXPORT const unsigned char traceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <trace/PublicHeader.h>


